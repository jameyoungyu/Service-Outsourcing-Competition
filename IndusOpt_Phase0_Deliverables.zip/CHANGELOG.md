# Changelog

本项目采用阶段标签记录竞赛开发过程。

## [Unreleased]

### Planned

- 阶段 1：FastAPI、PostgreSQL、Redis/RQ 工程骨架与 OpenAPI 字段契约。

## [0.1.0-requirements-candidate] - 2026-07-27

### Added

- A14 官方需求和统一评分标准映射；
- 第一版产品范围、数据口径和不做清单；
- Agent 白名单与禁止操作；
- 核心用例；
- 系统架构、数据流和状态机；
- 工业算法规范与统一错误语义；
- 训练/验证/测试防泄漏评测协议；
- OpenAPI 资源规划；
- GPT → Gemini 阶段 0 交接文档；
- 阶段状态记录。

### Not Implemented

- 未创建 backend/frontend 代码；
- 未创建数据库迁移；
- 未生成正式 OpenAPI；
- 未运行代码测试；
- 未完成 Gemini 低保真设计。
