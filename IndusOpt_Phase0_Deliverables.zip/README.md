# IndusOpt 阶段 0 交付包

版本：`v0.1.0-requirements-candidate`

本交付包完成 A14「IndusOpt 工模智优」阶段 0 的后端侧需求、架构、算法、评测与接口规划，并提供 GPT → Gemini 的阶段交接文档。

## 交付状态

- GPT 侧阶段 0 文档：已完成。
- 正式后端代码：未开始，符合阶段 0 边界。
- 数据库迁移：未创建。
- OpenAPI 文件：未生成；字段级接口将在阶段 1 冻结。
- Gemini 侧信息架构与低保真设计：待执行。
- 开发者口径确认：待确认。

## 文件目录

```text
.
├── README.md
├── PHASE_STATUS.md
├── CHANGELOG.md
└── docs
    ├── api
    │   └── openapi-plan.md
    ├── algorithms
    │   └── algorithm-specification.md
    ├── architecture
    │   ├── data-flow.md
    │   └── system-architecture.md
    ├── handoff
    │   └── PHASE_0_GPT_TO_GEMINI.md
    ├── requirements
    │   ├── official-requirements.md
    │   ├── scope-freeze.md
    │   └── use-cases.md
    └── testing
        └── evaluation-protocol.md
```

## 使用方式

将本目录中的文件复制到项目根目录。确认 `docs/`、`PHASE_STATUS.md` 与 `CHANGELOG.md` 无冲突后再提交 Git。

建议提交信息：

```bash
git add docs PHASE_STATUS.md CHANGELOG.md
git commit -m "docs: freeze A14 phase 0 requirements and architecture"
git tag v0.1.0-requirements
```

在打标签前，必须完成开发者确认和 Gemini 阶段 0 设计验收。
